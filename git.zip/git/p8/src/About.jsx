import React from 'react';

const About = () => {
    return (
        <div>
            <h2>About</h2>
            <p>This is the about page.</p>
        </div>
    )
}

export default About;