import React from 'react';

const HelloWorld = () => {
    return (
        <div>
            <p>Hello, World!</p>
        </div>
    )
}

export default HelloWorld;