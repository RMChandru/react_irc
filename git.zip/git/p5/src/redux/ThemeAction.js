export const TOGGLE_THEME = 'TOGGLE_THEME'

export const toggleTheme = () => ({
    type: TOGGLE_THEME
})